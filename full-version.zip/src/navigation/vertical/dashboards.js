import { Home, Circle } from 'react-feather'

export default [
  {
    id: 'dashboards',
    title: 'Dashboards',
    icon: <Home size={20} />,
    badge: 'light-warning',
    badgeText: '2',
    children: [
      {
        id: 'analyticsDash',
        title: 'Analytics',
        icon: <Circle size={12} />,
        navLink: '/dashboard/analytics'
      },
      {
        id: 'eCommerceDash',
        title: 'eCommerce',
        icon: <Circle size={12} />,
        navLink: '/dashboard/ecommerce'
      },
      {
        id: 'eCommerceDash',
        title: 'Shared',
        icon: <Circle size={12} />,
        navLink: '/dashboard/shared'
      },
      {
        id: 'eCommerceDash',
        title: 'DashBoard',
        icon: <Circle size={12} />,
        navLink: '/dashboard/index'
      },
      {
        id: 'eCommerceDash',
        title: 'buyMMP',
        icon: <Circle size={12} />,
        navLink: '/dashboard/buyMMP'
      },
      {
        id: 'eCommerceDash',
        title: 'Wallet',
        icon: <Circle size={12} />,
        navLink: '/dashboard/wallet'
      },
      {
        id: 'eCommerceDash',
        title: 'Transaction',
        icon: <Circle size={12} />,
        navLink: '/dashboard/transaction'
      },
      {
        id: 'eCommerceDash',
        title: 'FAQ',
        icon: <Circle size={12} />,
        navLink: '/dashboard/FAQ'
      },
      {
        id: 'eCommerceDash',
        title: 'loginhistory',
        icon: <Circle size={12} />,
        navLink: '/dashboard/loginhistory'
      },
      {
        id: 'eCommerceDash',
        title: 'Profile',
        icon: <Circle size={12} />,
        navLink: '/dashboard/Profile'
      },
      {
        id: 'eCommerceDash',
        title: 'Dragging',
        icon: <Circle size={12} />,
        navLink: '/dashboard/dragging'
      },
      {
        id: 'eCommerceDash',
        title: 'pie',
        icon: <Circle size={12} />,
        navLink: '/dashboard/pie'
      },
      {
        id: 'eCommerceDash',
        title: 'Review',
        icon: <Circle size={12} />,
        navLink: '/dashboard/review'
      },
      {
        id: 'eCommerceDash',
        title: 'Matrix',
        icon: <Circle size={12} />,
        navLink: '/dashboard/matrix'
      },
      {
        id: 'eCommerceDash',
        title: 'Chart',
        icon: <Circle size={12} />,
        navLink: '/apps/dashboard/chat'
      }
    ]
  }
]
