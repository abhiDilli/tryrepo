import { lazy } from 'react'

const DashboardRoutes = [
  // Dashboards
  {
    path: '/dashboard/analytics',
    component: lazy(() => import('../../views/dashboard/analytics'))
  },
  {
    path: '/dashboard/ecommerce',
    component: lazy(() => import('../../views/dashboard/ecommerce')),
    exact: true
  },
  {
    path: '/dashboard/index',
    component: lazy(() => import('../../views/dashboard/index')),
    exact: true
  },
  {
    path: '/dashboard/buyMMP',
    component: lazy(() => import('../../views/dashboard/buyMMP')),
    exact: true
  },
  {
    path: '/dashboard/wallet',
    component: lazy(() => import('../../views/dashboard/wallet')),
    exact: true
  },
  {
    path: '/dashboard/shared',
    component: lazy(() => import('../../views/dashboard/shared')),
    exact: true
  },
  {
    path: '/dashboard/transaction',
    component: lazy(() => import('../../views/dashboard/transaction')),
    exact: true
  },
  {
    path: '/dashboard/FAQ',
    component: lazy(() => import('../../views/dashboard/FAQ')),
    exact: true
  },
  {
    path: '/dashboard/loginhistory',
    component: lazy(() => import('../../views/dashboard/loginhistory')),
    exact: true
  },
  {
    path: '/dashboard/Profile',
    component: lazy(() => import('../../views/dashboard/Profile')),
    exact: true
  },
  {
    path: '/dashboard/dragging',
    component: lazy(() => import('../../views/dashboard/dragging')),
    exact: true
  },
  {
    path: '/dashboard/pie',
    component: lazy(() => import('../../views/dashboard/pie')),
    exact: true
  },
  {
    path: 'apps/dashboard/chat',
    component: lazy(() => import('../../views/dashboard/chat')), /* apps/dashboard/chat */
    exact: true
  },
  {
    path: '/dashboard/review',
    component: lazy(() => import('../../views/dashboard/Manage-review')),
    exact: true
  },
  {
    path: '/dashboard/matrix',
    component: lazy(() => import('../../views/dashboard/chatwitmatrix')),
    exact: true
  }
]

export default DashboardRoutes
