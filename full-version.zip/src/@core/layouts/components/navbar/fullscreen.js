import React, { useCallback } from 'react'
import { FullScreen, useFullScreenHandle } from "react-full-screen"

function fullScreen() {
    function toggleFullscreen(elem) {
        elem =  document.documentElement
      
        if (!document.fullScreenElement && !document.mozFullScreenElement &&
          !document.webkitFullscreenElement && !document.msFullscreenElement) {
          if (elem.requestFullscreen) {
            elem.requestFullscreen()
          } else if (elem.msRequestFullscreen) {
            elem.msRequestFullscreen()
          } else if (elem.mozRequestFullScreen) {
            elem.mozRequestFullScreen()
          } else if (elem.webkitRequestFullscreen) {
            elem.webkitRequestFullscreen(Element.ALLOW_KEYBOARD_INPUT)
          }
        } else {
          if (document.exitFullscreen) {
            document.exitFullscreen()
          } else if (document.msExitFullscreen) {
            document.msExitFullscreen()
          } else if (document.mozCancelFullScreen) {
            document.mozCancelFullScreen()
          } else if (document.webkitExitFullscreen) {
            document.webkitExitFullscreen()
          }
        }
      }
    return (
        <>
            <input type="button" value="fullscreen" style={{background:'inherit', color:'inherit'}} onClick={toggleFullscreen}></input>

        </>
    )
}

export default fullScreen