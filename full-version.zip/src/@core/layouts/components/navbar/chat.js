import React, { useEffect } from 'react'
import './chat.css'

import $ from 'jquery'
function chat() {
  function openLeftMenu() {
    document.getElementById("leftMenu").style.display = "block"
  }

  function closeLeftMenu() {
    document.getElementById("leftMenu").style.display = "none"
  }

  function openRightMenu() {
    document.getElementById("rightMenu").style.display = "block"
  }

  function closeRightMenu() {
    document.getElementById("rightMenu").style.display = "none"
  }

  return (
    <>

     
        <div class="w3-sidebar w3-bar-block w3-card w3-animate-right" style={{
          display: "none",
          right: "-10px",
          top:"0px",
          width:"300px"
        }} id="rightMenu">
          <button onClick={closeRightMenu} class="w3-bar-item w3-button w3-large">Close &times;</button>
          <a href="#" class="w3-bar-item w3-button">Link 1</a>
          <a href="#" class="w3-bar-item w3-button">Link 2</a>
          <a href="#" class="w3-bar-item w3-button">Link 3</a>
        </div>
      
      <span  onClick={openRightMenu}>hello</span>

    </>
  )
}

export default chat
