import React, { useEffect } from 'react'
import './message.css'
import Chat from './chat'
import img1 from './image/avatar-1.png'
import $ from 'jquery'
import * as Icon from 'react-feather'
import { NavItem, NavLink } from 'reactstrap'


function Message(props) {

  useEffect(() => {
    console.log("message", {props})
  }, [])
  function openNav() {
    document.getElementById("mySidenav").style.width = "350px"
  }
  function closeNav() {
    document.getElementById("mySidenav").style.width = "0"
  }
  function openLeftMenu() {
    document.getElementById("leftMenu").style.display = "block"
  }

  function closeLeftMenu() {
    document.getElementById("leftMenu").style.display = "none"
  }

  function openRightMenu() {
    document.getElementById("rightMenu").style.display = "block"
  }

  function closeRightMenu() {
    document.getElementById("rightMenu").style.display = "none"
  }
  return (
    <>
      <div id="mySidenav" class="sidenav">
        <a href="javascript:void(0)" class="closebtn" onClick={closeNav}>&times;</a>

        <div style={{ marginTop: '-40px' }} >
          <ul class="nav nav-tabs" role="tablist">
            <li class="nav-item">
              <a class="nav-link active" href="#profile" role="tab" data-toggle="tab" style={{ fontSize: '17px' }}>Message</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#buzz" role="tab" data-toggle="tab" style={{ fontSize: '17px' }}>Setting</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#references" role="tab" data-toggle="tab" style={{ fontSize: '17px' }}>Activity</a>
            </li>
          </ul>
        </div>
        {/* <div id="mySidenav" class="sidenav">
        <a href="javascript:void(0)" class="closebtn" onClick={w3_close}>&times;</a>
        </div> */}
        {/* #################################### chat#################################### */}
        <div class="w3-sidebar w3-bar-block w3-card w3-animate-right" style={{
          display: "none",
          right: "0px",
          top: "0px",
          width: "350px"
        }} id="rightMenu">
          <button onClick={closeRightMenu} class="w3-bar-item w3-button w3-large" >&laquo;<span>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Sunil Rajput</span> </button>
          <div class="mesgs">
            <div class="msg_history">
              <div class="incoming_msg">
                <div class="incoming_msg_img"> <img src="https://ptetutorials.com/images/user-profile.png" alt="sunil" style={{ width: '40px', heigth: '40px' }} /> </div>
                <div class="received_msg">
                  <div class="received_withd_msg">
                    <p>Test which is a new </p>
                    <span class="time_date"> 11:01 AM    |    June 9</span></div>
                </div>
              </div>
              <div class="outgoing_msg">
                <div class="sent_msg">
                  <p>Test which is a  have all
                    solutions</p>
                  <span class="time_date"> 11:01 AM    |    June 9</span> </div>
              </div>
              <div class="incoming_msg">
                <div class="incoming_msg_img"> <img src="https://ptetutorials.com/images/user-profile.png" alt="sunil" style={{ width: '40px', heigth: '40px' }} /> </div>
                <div class="received_msg">
                  <div class="received_withd_msg">
                    <p>Test, which is a  to have</p>
                    <span class="time_date"> 11:01 AM    |    Yesterday</span></div>
                </div>
              </div>
              <div class="outgoing_msg">
                <div class="sent_msg">
                  <p>Apollo University, Delhi, India Test</p>
                  <span class="time_date"> 11:01 AM    |    Today</span> </div>
              </div>
              {<div class="incoming_msg">
                <div class="incoming_msg_img"> <img src="https://ptetutorials.com/images/user-profile.png" alt="sunil" style={{ width: '40px', heigth: '40px' }} /> </div>
                <div class="received_msg">
                  <div class="received_withd_msg">
                    <p>We work directly with our designers and suppliers,
                      and sell direct to you</p>
                    <span class="time_date"> 11:01 AM    |    Today</span></div>
                </div>
              </div>}
            </div>
            <div class="type_msg">
              <div class="input_msg_write">
                <input type="text" class="write_msg" placeholder="Type a message" />
                <button class="msg_send_btn" type="button"><i class="fa fa-paper-plane-o" aria-hidden="true"></i></button>
              </div>
            </div>
          </div>
        </div>
        {/* ############################ Chat ############################################# */}
        <div class="tab-content">
          <div role="tabpanel" class="tab-pane fade in active" id="profile">
            {/* ############################# Message ############################################ */}
            <div class="inbox_msg">
              <div class="inbox_people">
                <div class="headind_srch">
                  <div class="recent_heading">
                    <h4>Recent</h4>
                  </div>
                  <div class="srch_bar">
                    <div class="stylish-input-group">
                      <input type="text" class="search-bar" placeholder="Search" />
                      <span class="input-group-addon">
                        <button type="button"> <i class="fa fa-search" aria-hidden="true"></i> </button>
                      </span> </div>
                  </div>
                </div>
                {/* <span  >hello</span> */}
                <div class="inbox_chat">
                  <div class="chat_list active_chat msg" onClick={openRightMenu}  >
                    <div class="chat_people">

                      <div class="chat_img"> <img src="https://ptetutorials.com/images/user-profile.png" alt="sunil" style={{ width: '40px', heigth: '40px' }} /> </div>
                      <div class="chat_ib">
                        <h5>Sunil Rajput <span class="chat_date">Dec 25</span></h5>
                        <p>Test,  under one roof.</p>
                        {/*  <Chat /> */}
                      </div>
                    </div>
                  </div>
                  <div class="chat_list msg" onClick={openRightMenu} >
                    <div class="chat_people">
                      <div class="chat_img"> <img src="https://ptetutorials.com/images/user-profile.png" alt="sunil" style={{ width: '40px', heigth: '40px' }} /> </div>
                      <div class="chat_ib">
                        <h5>Rahul Kumar <span class="chat_date">Dec 25</span></h5>
                        <p> under one roof.</p>
                      </div>
                    </div>
                  </div>
                  <div class="chat_list msg" onClick={openRightMenu} >
                    <div class="chat_people">
                      <div class="chat_img"> <img src="https://ptetutorials.com/images/user-profile.png" alt="sunil" style={{ width: '40px', heigth: '40px' }} /> </div>
                      <div class="chat_ib">
                        <h5>Ajay Singh<span class="chat_date">Dec 25</span></h5>
                        <p>Test, e roof.</p>
                      </div>
                    </div>
                  </div>
                  <div class="chat_list msg" onClick={openRightMenu}>
                    <div class="chat_people">
                      <div class="chat_img"> <img src="https://ptetutorials.com/images/user-profile.png" alt="sunil" style={{ width: '40px', heigth: '40px' }} /> </div>
                      <div class="chat_ib">
                        <h5>Sunil Rajput <span class="chat_date">Dec 25</span></h5>
                        <p>Test, which is </p>
                      </div>
                    </div>
                  </div>
                  <div class="chat_list msg" onClick={openRightMenu}>
                    <div class="chat_people">
                      <div class="chat_img"> <img src="https://ptetutorials.com/images/user-profile.png" alt="sunil" style={{ width: '40px', heigth: '40px' }} /> </div>
                      <div class="chat_ib">
                        <h5>Rocky Bhai <span class="chat_date">Dec 25</span></h5>
                        <p>Test, which is a  roof.</p>
                      </div>
                    </div>
                  </div>
                  <div class="chat_list msg" onClick={openRightMenu}>
                    <div class="chat_people">
                      <div class="chat_img"> <img src="https://ptetutorials.com/images/user-profile.png" alt="sunil" style={{ width: '40px', heigth: '40px' }} /> </div>
                      <div class="chat_ib">
                        <h5>Ram Singh <span class="chat_date">Dec 25</span></h5>
                        <p>l solutions
                          astrology under one roof.</p>
                      </div>
                    </div>
                  </div>
                  <div class="chat_list msg" onClick={openRightMenu}>
                    <div class="chat_people">
                      <div class="chat_img"> <img src="https://ptetutorials.com/images/user-profile.png" alt="sunil" style={{ width: '40px', heigth: '40px' }} /> </div>
                      <div class="chat_ib">
                        <h5>Preeti kumari <span class="chat_date">Dec 25</span></h5>
                        <p>Test, which is a </p>
                      </div>
                    </div>
                  </div>
                  <div class="chat_list msg" onClick={openRightMenu}>
                    <div class="chat_people">
                      <div class="chat_img"> <img src="https://ptetutorials.com/images/user-profile.png" alt="sunil" style={{ width: '40px', heigth: '40px' }} /> </div>
                      <div class="chat_ib">
                        <h5>Guarav Kumar <span class="chat_date">Dec 25</span></h5>
                        <p>Test, which is a </p>
                      </div>
                    </div>
                  </div>
                  <div class="chat_list msg" onClick={openRightMenu}>
                    <div class="chat_people">
                      <div class="chat_img"> <img src="https://ptetutorials.com/images/user-profile.png" alt="sunil" style={{ width: '40px', heigth: '40px' }} /> </div>
                      <div class="chat_ib">
                        <h5>Rohit saini <span class="chat_date">Dec 25</span></h5>
                        <p>Test, which is a </p>
                      </div>
                    </div>
                  </div>
                  <div class="chat_list msg" onClick={openRightMenu}>
                    <div class="chat_people">
                      <div class="chat_img"> <img src="https://ptetutorials.com/images/user-profile.png" alt="sunil" style={{ width: '40px', heigth: '40px' }} /> </div>
                      <div class="chat_ib">
                        <h5>Sunil Rajput <span class="chat_date">Dec 25</span></h5>
                        <p>Test, which is a </p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* ############################### end ############################################## */}
          </div>
          <div role="tabpanel" class="tab-pane fade" id="buzz">

            <p class="setting-header " style={{ fontWeight: '900' }}>GENERAL SETTINGS</p>
            <ul class="collection border-none">
              <li class="collection-item border-none" style={{ listStyle: 'none', borderBottom: 'none' }}>
                <div class="m-0">
                  <span>Notifications</span>
                  <div class="switch right">
                    <label>
                      <input type="checkbox" />
                      <span class="slider round"></span>
                    </label>
                  </div>
                </div>
              </li>
              <li class="collection-item border-none" style={{ listStyle: 'none', borderBottom: 'none' }}>
                <div class="m-0">
                  <span>Show recent activity</span>
                  <div class="switch right">
                    <label>
                      <input type="checkbox" />
                      <span class="slider round"></span>
                    </label>
                  </div>
                </div>
              </li>
              <li class="collection-item border-none" style={{ listStyle: 'none', borderBottom: 'none' }}>
                <div class="m-0">
                  <span>Show recent activity</span>
                  <div class="switch right">
                    <label>
                      <input type="checkbox" />
                      <span class="slider round"></span>
                    </label>
                  </div>
                </div>
              </li>
              <li class="collection-item border-none" style={{ listStyle: 'none', borderBottom: 'none' }}>
                <div class="m-0">
                  <span>Show Task statistics</span>
                  <div class="switch right">
                    <label>
                      <input type="checkbox" />
                      <span class="slider round"></span>
                    </label>
                  </div>
                </div>
              </li>
              <li class="collection-item border-none" style={{ listStyle: 'none', borderBottom: 'none' }}>
                <div class="m-0">
                  <span>Show your emails</span>
                  <div class="switch right">
                    <label>
                      <input type="checkbox" />
                      <span class="slider round"></span>
                    </label>
                  </div>
                </div>
              </li>
              <li class="collection-item border-none" style={{ listStyle: 'none', borderBottom: 'none' }}>
                <div class="m-0">
                  <span>Email Notifications</span>
                  <label class="switch right">
                    <input type="checkbox" />
                    <span class="slider round"></span>
                  </label>
                </div>
              </li>
            </ul>

            {/* second  */}

            <p class="setting-header " style={{ fontWeight: '900' }}>GENERAL SETTINGS</p>
            <ul class="collection border-none">
              <li class="collection-item border-none" style={{ listStyle: 'none', borderBottom: 'none' }}>
                <div class="m-0">
                  <span>Notifications</span>
                  <div class="switch right">
                    <label>
                      <input type="checkbox" />
                      <span class="slider round"></span>
                    </label>
                  </div>
                </div>
              </li>
              <li class="collection-item border-none" style={{ listStyle: 'none', borderBottom: 'none' }}>
                <div class="m-0">
                  <span>Show recent activity</span>
                  <div class="switch right">
                    <label>
                      <input type="checkbox" />
                      <span class="slider round"></span>
                    </label>
                  </div>
                </div>
              </li>
              <li class="collection-item border-none" style={{ listStyle: 'none', borderBottom: 'none' }}>
                <div class="m-0">
                  <span>Show recent activity</span>
                  <div class="switch right">
                    <label>
                      <input type="checkbox" />
                      <span class="slider round"></span>
                    </label>
                  </div>
                </div>
              </li>
              <li class="collection-item border-none" style={{ listStyle: 'none', borderBottom: 'none' }}>
                <div class="m-0">
                  <span>Show Task statistics</span>
                  <div class="switch right">
                    <label>
                      <input type="checkbox" />
                      <span class="slider round"></span>
                    </label>
                  </div>
                </div>
              </li>
              <li class="collection-item border-none" style={{ listStyle: 'none', borderBottom: 'none' }}>
                <div class="m-0">
                  <span>Show your emails</span>
                  <div class="switch right">
                    <label>
                      <input type="checkbox" />
                      <span class="slider round"></span>
                    </label>
                  </div>
                </div>
              </li>
              <li class="collection-item border-none" style={{ listStyle: 'none', borderBottom: 'none' }}>
                <div class="m-0">
                  <span>Email Notifications</span>
                  <label class="switch right">
                    <input type="checkbox" />
                    <span class="slider round"></span>
                  </label>
                </div>
              </li>
            </ul>

          </div>
          {/* ################################Activity############################## */}
          <div role="tabpanel" class="tab-pane fade" id="references">
            <div class="stepper d-flex flex-column mt-5 ml-2">
              <div class="d-flex mb-1">
                <div class="d-flex flex-column pr-2 align-items-center">
                  <div class="rounded-circle py-2 px-2 bg-primary text-white mb-1">1</div>
                  <div class="line h-100"></div>
                </div>
                <div>
                  <h5 class="text-dark">Create your application respository</h5>
                  <p class="lead text-muted pb-3">Choose your website name & create repository</p>
                </div>
              </div>
              <div class="d-flex mb-1">
                <div class="d-flex flex-column pr-2 align-items-center">
                  <div class="rounded-circle py-2 px-2 bg-primary text-white mb-1">2</div>
                  <div class="line h-100"></div>
                </div>
                <div>
                  <h5 class="text-dark">Clone application respository</h5>
                  <p class="lead text-muted pb-3">Go to your dashboard and clone Git respository from the url in the dashboard of your application</p>
                </div>
              </div>
              <div class="d-flex mb-1">
                <div class="d-flex flex-column pr-2 align-items-center">
                  <div class="rounded-circle py-2 px-2 bg-primary text-white mb-1">3</div>
                  <div class="line h-100 "></div>
                </div>
                <div>
                  <h5 class="text-dark">Make changes and push!</h5>
                  <p class="lead text-muted pb-3">Now make changes to your application source code, test it then commit &amp; push</p>
                </div>
              </div>
              <div class="d-flex mb-1">
                <div class="d-flex flex-column pr-2 align-items-center">
                  <div class="rounded-circle py-2 px-2 bg-primary text-white mb-1">4</div>
                  <div class="line h-100 d-none"></div>
                </div>
                <div>
                  <h5 class="text-dark">Make changes and push!</h5>
                  <p class="lead text-muted pb-3">Now make changes to your application source code, test it then commit &amp; push</p>
                </div>
              </div>
            </div>
          </div>
          {/* #################################Activity############################# */}
        </div>

      </div>
      <NavLink className='nav-link-search'>
        <Icon.Search className='ficon' />
      </NavLink>

      {/* <span onClick={openNav} style={{ cursor: "pointer", border: "none", padding: "5px" }}><i class="material-icons ficon">chat</i></span> */}
    </>
  )
}

export default Message
