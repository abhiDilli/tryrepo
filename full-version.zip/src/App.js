// ** Router Import
import Router from './router/Router'
import 'bootstrap/dist/css/bootstrap.min.css'

const App = props => <Router />

export default App
